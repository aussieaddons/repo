CATEGORIES = ['Live Matches',
              'Latest News']

VIDEOS_URL = 'https://apinew.cricket.com.au/videos?Limit=30'

MATCHES_URL = 'https://apinew.cricket.com.au/matches?inProgressLimit=15&completedLimit=0&upcomingLimit=0&format=json'

MATCH_STREAM_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/807051129001/videos/'

BRIGHTCOVE_PK = 'BCpkADawqM17uKWqEHlBulux385QZ_BoC6x04LRDmsykNRb4uwwRJ8x38iHNk-7kxEqJUu3qZGMFCiKA4d8SeUB0c40Z46CutsbR219abTqUHi82DqCZMUJo36s'
