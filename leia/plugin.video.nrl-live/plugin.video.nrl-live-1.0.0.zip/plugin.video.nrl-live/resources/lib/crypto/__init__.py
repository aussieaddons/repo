# -*- coding: iso-8859-1 -*-
""" crypto
    CryptoPy - pure python cryptographic libraries

    Copyright � (c) 2002 by Paul A. Lambert
    Read LICENSE.txt for license information.
"""
