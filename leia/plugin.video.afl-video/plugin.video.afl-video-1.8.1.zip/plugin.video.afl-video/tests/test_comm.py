import mock
import pytest
import requests_mock
import sys
import unittest

import comm

@requests_mock.mock()
class TestComm(unittest.TestCase):

    def test_comm_fetch_url(self, m):
        m.get('http://testurl.com', text='return_output')
        self.assertEqual(comm.fetch_url('http://testurl.com'), 'return_output')
