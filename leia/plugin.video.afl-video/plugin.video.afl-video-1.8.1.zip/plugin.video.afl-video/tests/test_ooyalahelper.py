import mock
import pytest
import requests_mock
import sys
import unittest

import ooyalahelper


class TestOoyalahelper(unittest.TestCase):

    @mock.patch('ooyalahelper.clear_token')
    def test_clear_token(self, mock_clear_token):
        with mock.patch.object('ooyalahelper.cache') as mock_cache:
            mock_cache.delete.assert_called_with('AFL_TOKEN')
