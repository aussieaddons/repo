# script.module.drmhelper
### Module to assist in aquiring components to enable DRM playback in Kodi

This module is required for add-ons which can play back Widevine DRM protected videos. It will fetch and install the required content decrypter module and single sample decrypter module from our repo, and attempt to install the required inputstream.adaptive add-on.
