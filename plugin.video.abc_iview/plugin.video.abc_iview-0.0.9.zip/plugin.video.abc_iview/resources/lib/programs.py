import sys
import config
import utils
import comm

try:
	import xbmc, xbmcgui, xbmcplugin
except ImportError:
	pass # for PC debugging

def make_list(url):
	params = utils.get_url(url)	

	try:
		# Show a dialog
		pDialog = xbmcgui.DialogProgress()
		pDialog.create('iView', 'Getting Episode List')
		pDialog.update(50)

		programs = get_programs(params["series_id"])
		# fill media list
		ok = fill_media_list(programs)
	except:
		# oops print error message
		print "ERROR: %s (%d) - %s" % (sys.exc_info()[2].tb_frame.f_code.co_name, sys.exc_info()[2].tb_lineno, sys.exc_info()[1])
		ok = False

	# send notification we're finished, successfully or unsuccessfully
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=ok)


def get_programs(series_id):
	iview_config = comm.get_config()
	return comm.get_series_items(iview_config, series_id)


def fill_media_list(programs):
	try:	
		ok = True
		for p in programs:

			listitem=xbmcgui.ListItem(label=p.get_list_title(), iconImage=p.thumbnail, thumbnailImage=p.thumbnail)
			listitem.setInfo('video', p.get_xbmc_list_item())

			print p.get_xbmc_list_item()

			# Build the URL for the program, including the list_info
			url = "%s?%s" % (sys.argv[0], p.make_xbmc_url())

			# Add the program item to the list
			ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)
		xbmcplugin.setContent(handle=int(sys.argv[1]), content='episodes')
	except:
		# user cancelled dialog or an error occurred
		print "ERROR: %s (%d) - %s" % ( sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )
		ok = False
	return ok
