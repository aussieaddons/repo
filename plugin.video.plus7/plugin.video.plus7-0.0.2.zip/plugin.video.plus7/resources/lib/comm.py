import urllib2
import config
import classes
import utils
import re
import datetime
import time

from BeautifulSoup import BeautifulStoneSoup
import simplejson as json

try:
	import xbmc, xbmcgui, xbmcplugin, xbmcaddon
except ImportError:
	pass # for PC debugging

cache = False

def fetch_url(url):
	"""	Simple function that fetches a URL using urllib2.
		An exception is raised if an error (e.g. 404) occurs.
	"""
	print "Plus7: Fetching URL: %s" % url
	http = urllib2.urlopen(urllib2.Request(url, None))
	return http.read()


def get_index():
	"""	This function pulls in the index, which contains the TV series
		that are available to us. The index is possibly encrypted, so we
		must decrypt it here before passing it to the parser.
	"""
	series_list = []
	data = fetch_url(config.index_url)
	data = data.replace('\n','')
	token = re.findall(r"<!-- Body Content  -->(.*)<!-- //Body Content -->", data)[0]
	token2 = re.findall(r'<div class="bd" id="atoz">(.*)</div>', token)[0]

	urls = re.findall(r'<a href="(.*?)"', token2)
	titles = re.findall(r'alt="(.*?)"', token2)
	imgs = re.findall(r'src="(.*?)\?', token2)

	for i in xrange(len(urls)-1):
		series = classes.Series()
		series.title = titles[i]
		series.thumbnail = imgs[i]
		series.url = urls[i]
		series_list.append(series)

	return series_list

def get_series(series_id):
	""" 
	"""
	program_list = []
	url = config.series_url % series_id

	data = fetch_url(url)	
	data = data.replace('\n','')
	token3 = re.findall(r'<ul id="related-episodes" class="featlist">(.*?)</ul>', data)[0]
	token4 = re.findall(r'<span class="title">(.*?)</span>', token3)

	# ['Episode desc',
	# 'Episode desc']
	token5 = re.findall(r'<p>(.*?)</p>', token3)

	# [' Wed 14 July, series 4 episode 2', 
	# ' Wed 14 July, series 4 episode 1']
	token6 = re.findall(r'<span class="subtitle">(.*?)</span>', token3)

	# ['http://l.yimg.com/ea/img/-/100714/0714_city_homicide_ep56v2_sml-163qgka.jpg',
	# 'http://l.yimg.com/ea/img/-/100714/0714_city_homicide_ep55v2_sml-163qgjl.jpg']	
	token7 = re.findall(r'src="(.*?)\?', token3)

	# ['/plus7/city-homicide/-/watch/7583800/wed-14-july-series-4-episode-2/',
	# '/plus7/city-homicide/-/watch/7583794/wed-14-july-series-4-episode-1/']
	token8 = re.findall(r'<h3><a href="(.*?)">', token3)

	num_episodes = len(token5)

	for i in xrange(num_episodes):
		program = classes.Program()
		program.title = token4[i]
		program.description = token5[i]
		program.thumbnail = token7[i]
		program.url_path = token8[i]

		# season 4 episode 2
		program.episode = token6[i].split(',')[1].lstrip(" ").rstrip(" ")

		# Set the date
		date_string = token6[i].split(',')[0].lstrip(" ").rstrip(" ")
		date = "%s %s" % (date_string, program.get_year())
		timestamp = time.mktime(time.strptime(date, '%a %d %b %Y'))
		program.date = datetime.date.fromtimestamp(timestamp)

		program_list.append(program)

	return program_list


def get_program(path):

	# This stuff needs to go into parser
	index = fetch_url("http://au.tv.yahoo.com%s" % path) 

	program = classes.Program()

	program.id = re.findall("vid : '(.*?)'", index)[0]
	program.title = re.findall("<h1>(.*?)</h1>", index)[0]
	program.category = re.findall("Genre: <strong>(.*?)</strong>", index)[0]
	program.rating = re.findall("Classified: <strong>(.*?)</strong>", index)[0]

	# Get the URL, but split it from the '?', to get the high-res image
	program.thumbnail = re.findall('<img class="listimg" src="(.*?)" alt', index)[0].split("?")[0]

	# Get metadata
	url = "http://cosmos.bcst.yahoo.com/rest/v2/pops;id=%s;lmsoverride=1" % program.id
	index = fetch_url(url)

	program.episode_title = re.findall("<title><!\[CDATA\[(.*?)\]\]></title>", index)[0].split(": ")[1]
	program.description = re.findall("<description><!\[CDATA\[(.*?)\]\]></description>", index)[0]
	program.date = re.findall("<media:pubStart><!\[CDATA\[(.*?)\]\]></media:pubStart>", index)[0]
	#program.thumbnail = re.findall('<media:content medium="image" url="(.*?)" name=', index)[0]

	date_string = program.episode_title.split(',')[0].lstrip(" ").rstrip(" ")
	date = "%s %s" % (date_string, datetime.datetime.now().year)
	timestamp = time.mktime(time.strptime(date, '%a %d %b %Y'))
	program.date = datetime.date.fromtimestamp(timestamp)

	# Get stream
	url = "http://cosmos.bcst.yahoo.com/rest/v2/pops;id=%s;lmsoverride=1;element=stream;bw=1200" % program.id
	index = fetch_url(url)

	program.rtmp_host = re.findall('url="(.*?)"', index)[0]
	program.rtmp_path = re.findall('path="(.*?)"', index)[0]
	program.duration = re.findall('duration="(.*?)"', index)[0]

	return program

