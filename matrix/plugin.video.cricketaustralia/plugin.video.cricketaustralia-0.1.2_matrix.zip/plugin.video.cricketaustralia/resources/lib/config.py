# flake8: noqa
CATEGORIES = ['Live Matches',
              'Latest News']

VIDEOS_URL = 'https://apiv2.cricket.com.au/mobile/videos?Country=AU&Limit=50&DigitalProperty=caliveapp&format=json&jsconfig=eccn'

MATCHES_URL = 'https://apiv2.cricket.com.au/mobile/views/stream?Country=AU&format=json&jsconfig=eccn'

MATCH_STREAM_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/807051129001/videos/'

BRIGHTCOVE_PK = 'BCpkADawqM2ueJ2wfUJO43jPx_Ws9NEaUMDIl4OJumomT89KzeOhyWxJC9gz0EoVDGPNpULiPF7inqUyzdHOK3k_r1-Z_zOxFDEDpMzU9_iobgqlVGNAtk8VA2E'
